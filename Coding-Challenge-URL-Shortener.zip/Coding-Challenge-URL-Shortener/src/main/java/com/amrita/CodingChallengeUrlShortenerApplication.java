package com.amrita;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodingChallengeUrlShortenerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodingChallengeUrlShortenerApplication.class, args);
	}
}
