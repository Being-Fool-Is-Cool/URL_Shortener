package com.amrita.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.amrita.dto.ShortenUrlRequest;
import com.amrita.exception.UrlException;
import com.amrita.service.IUrlShortService;
import com.google.common.hash.Hashing;

@Controller
public class UrlShortController {
	@Autowired
    private IUrlShortService urlStoreService;
	

    @RequestMapping(value="/", method=RequestMethod.GET)
    public String showForm(ShortenUrlRequest request)
    {
    	System.out.println("line 35");
    	return "shortener";
    }
    
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public void redirectToUrl(@PathVariable String id, HttpServletResponse resp)throws UrlException {
    	final String url = urlStoreService.findUrlById(id);
        if (url != null) {
            resp.addHeader("Location", url);
            resp.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
        } else {
            try {
				resp.sendError(HttpServletResponse.SC_NOT_FOUND);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				
			}
        }
    }
    
    @RequestMapping(value="/", method = RequestMethod.POST)
    public ModelAndView shortenUrl(HttpServletRequest httpRequest,
            @Valid ShortenUrlRequest request,
            BindingResult bindingResult) {
        String url = request.getUrl();
        if (!isUrlValid(url)) {
        	bindingResult.addError(new ObjectError("url", "Invalid url format: " + url));
        	if (bindingResult.hasErrors())
        	{
        		System.out.println("**********Invalid URL *******");
        	}
        }

        ModelAndView modelAndView = new ModelAndView("shortener");
        if (!bindingResult.hasErrors()) {
            final String id = Hashing.murmur3_32().hashString(url, StandardCharsets.UTF_8).toString();
            urlStoreService.storeUrl(id, url);
            modelAndView.addObject("shortenedUrl",id);
        }
        return modelAndView;
    }
    
    private boolean isUrlValid(String url) {
        boolean valid = true;
        try {
            new URL(url);
        } catch (MalformedURLException e) {
            valid = false;
        }
        return valid;
    }
}
