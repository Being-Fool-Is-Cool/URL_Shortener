package com.amrita.service;

public interface IUrlShortService {
	String findUrlById(String id);

    void storeUrl(String id, String url);
}
