package com.amrita.service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;
@Service
public class UrlShortServiceImpl implements IUrlShortService{
	private Map<String, String> urlByIdMap = new ConcurrentHashMap<>();
	@Override
	public String findUrlById(String id) {
		// TODO Auto-generated method stub
		System.out.println("String findUrlById(String id)");
		System.out.println(urlByIdMap.get(id));
		return urlByIdMap.get(id);
	}

	@Override
	public void storeUrl(String id, String url) {
		// TODO Auto-generated method stub
		urlByIdMap.put(id, url);
	}

}
